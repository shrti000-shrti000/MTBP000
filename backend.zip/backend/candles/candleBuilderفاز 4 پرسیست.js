import IndicatorDispatcher from "../indicators/IndicatorDispatcher.js";

const DEBUG = false;

export class CandleBuilder {


constructor(store) {

    this.store = store;


    // ============================
    // Supported Timeframes
    // ============================
this.timeframes = {

    "1m": 10 * 1000,

    "5m": 20 * 1000,

    "15m": 30 * 1000,

    "30m": 60 * 1000,

    "1h": 120 * 1000,

    "4h": 300 * 1000,

};

    // ============================
    // Current Open Candles
    // ============================

    this.current = Object.create(null);

}



// ======================================
// INIT SYMBOL
// ======================================

initSymbol(symbol) {

    if (!this.current[symbol]) {

        this.current[symbol] =
            Object.create(null);

    }

}



// ======================================
// PROCESS TICK
// ======================================

onTick(tick) {


    if (!tick) return;


    const {

        symbol,

        price,

        volume = 0,

        time,

    } = tick;



    if (!symbol) return;

    if (price == null) return;



    this.initSymbol(symbol);



    const now =
        time || Date.now();



    // ======================================
    // Build every timeframe
    // ======================================

    for (const tf of Object.keys(this.timeframes)) {


        const interval =
            this.timeframes[tf];



        const bucket =
            Math.floor(now / interval) * interval;



        let candle =
            this.current[symbol][tf];



        // ==================================
        // NEW CANDLE
        // ==================================

        if (!candle || candle.openTime !== bucket) {



            // ==============================
            // CLOSED CANDLE
            // ==============================

            if (candle) {


                const closedCandle = {
                    ...candle
                };



                // ==============================
                // SAVE CANDLE
                // ==============================

                this.store.push(
                    symbol,
                    tf,
                    closedCandle
                );



                // ==============================
                // TEST LOG
                // ==============================

                //console.log(
                 //   "CANDLE CLOSE",
                 //   symbol,
                 //   tf,
                 //   closedCandle.close
                //);



                // ==============================
                // INDICATOR PIPELINE
                // ==============================


if (DEBUG) {

    console.log(

        "🚀 SENDING TO INDICATOR",

        symbol,

        tf,

        closedCandle

    );

}


IndicatorDispatcher.dispatch(
    "TOOBIT",
    symbol,
    tf,
    closedCandle
);


            }





            // ==============================
            // START NEW CANDLE
            // ==============================


            this.current[symbol][tf] = {


                symbol,


                interval: tf,


                openTime: bucket,


                open: Number(price),


                high: Number(price),


                low: Number(price),


                close: Number(price),


                volume: Number(volume),


            };


            continue;

        }




        // ==================================
        // UPDATE CURRENT CANDLE
        // ==================================


        candle.close =
            Number(price);



        if (price > candle.high)

            candle.high =
                Number(price);



        if (price < candle.low)

            candle.low =
                Number(price);



        candle.volume +=
            Number(volume);



    }


}




// ======================================
// GET CURRENT
// ======================================

getCurrent(
    symbol,
    timeframe = "1m"
) {


    return (

        this.current?.[symbol]?.[timeframe]

        ||

        null

    );


}



// ======================================
// GET ALL CURRENT
// ======================================

getAllCurrent(symbol) {


    return (

        this.current?.[symbol]

        ||

        Object.create(null)

    );


}



// ======================================
// GET TIMEFRAMES
// ======================================

getTimeframes() {


    return Object.keys(
        this.timeframes
    );


}



// ======================================
// CLEAR SYMBOL
// ======================================

clear(symbol) {


    delete this.current[symbol];


}


}