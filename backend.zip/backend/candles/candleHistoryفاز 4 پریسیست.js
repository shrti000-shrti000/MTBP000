export class CandleHistory {
  constructor(baseUrl) {
    this.baseUrl = baseUrl;
  }

  // 📊 گرفتن کندل‌های تاریخی (OHLCV)
  async getOHLCV(symbol, interval = "1m", limit = 200) {
    try {
      const url =
        `${this.baseUrl}/api/v1/market/kline` +
        `?symbol=${symbol}&interval=${interval}&limit=${limit}`;

      const res = await fetch(url);
      const json = await res.json();

      if (!json || !json.data) return [];

      return json.data.map((c) => ({
        symbol,
        openTime: c.t,
        open: Number(c.o),
        high: Number(c.h),
        low: Number(c.l),
        close: Number(c.c),
        volume: Number(c.v),
        closeTime: c.T
      }));
    } catch (err) {
      console.log("CandleHistory Error:", err.message);
      return [];
    }
  }

  // 📊 چند symbol همزمان
  async getBatch(symbols, interval = "1m", limit = 200) {
    const result = {};

    for (const s of symbols) {
      result[s] = await this.getOHLCV(s, interval, limit);
    }

    return result;
  }
}