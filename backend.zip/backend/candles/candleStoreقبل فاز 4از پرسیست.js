export class CandleStore {
  constructor(maxSize = 500) {
    this.maxSize = maxSize;

    // =========================
    // STRUCTURE
    //
    // {
    //   BTCUSDT: {
    //      "1m": [],
    //      "5m": [],
    //      "15m": [],
    //      "30m": [],
    //      "1h": [],
    //      "4h": []
    //   }
    // }
    // =========================

    this.data = Object.create(null);

    this.timeframes = [
      "1m",
      "5m",
      "15m",
      "30m",
      "1h",
      "4h",
    ];
  }

  // ====================================
  // INIT SYMBOL
  // ====================================

  init(symbol) {
    if (!this.data[symbol]) {
      this.data[symbol] = Object.create(null);

      for (const tf of this.timeframes) {
        this.data[symbol][tf] = [];
      }
    }
  }

  // ====================================
  // INIT TIMEFRAME
  // ====================================

  initTimeframe(symbol, timeframe) {
    this.init(symbol);

    if (!this.data[symbol][timeframe]) {
      this.data[symbol][timeframe] = [];
    }
  }

  // ====================================
  // LOAD HISTORY
  // ====================================

  addHistory(symbol, timeframe, candles = []) {
    this.initTimeframe(symbol, timeframe);

    this.data[symbol][timeframe] =
      candles.slice(-this.maxSize);
  }

  // ====================================
  // PUSH CLOSED CANDLE
  // ====================================

  push(symbol, timeframe, candle) {
    this.initTimeframe(symbol, timeframe);

    const arr = this.data[symbol][timeframe];

    const last = arr[arr.length - 1];

    // جلوگیری از ثبت دوباره همان کندل
    if (
      last &&
      last.openTime === candle.openTime
    ) {
      arr[arr.length - 1] = candle;
      return;
    }

    arr.push(candle);

    while (arr.length > this.maxSize) {
      arr.shift();
    }
  }

  // ====================================
  // GET ALL
  // ====================================

  get(symbol, timeframe = "1m") {
    this.initTimeframe(symbol, timeframe);

    return this.data[symbol][timeframe];
  }

  // ====================================
  // LAST
  // ====================================

  last(symbol, timeframe = "1m") {
    this.initTimeframe(symbol, timeframe);

    const arr = this.data[symbol][timeframe];

    if (!arr.length) {
      return null;
    }

    return arr[arr.length - 1];
  }

  // ====================================
  // SIZE
  // ====================================

  size(symbol, timeframe = "1m") {
    this.initTimeframe(symbol, timeframe);

    return this.data[symbol][timeframe].length;
  }

  // ====================================
  // CLEAR ONE TF
  // ====================================

  clear(symbol, timeframe) {
    this.initTimeframe(symbol, timeframe);

    this.data[symbol][timeframe] = [];
  }

  // ====================================
  // CLEAR SYMBOL
  // ====================================

  clearSymbol(symbol) {
    this.init(symbol);

    for (const tf of this.timeframes) {
      this.data[symbol][tf] = [];
    }
  }

  // ====================================
  // SNAPSHOT
  // ====================================

  snapshot() {
    return this.data;
  }

  // ====================================
  // AVAILABLE TIMEFRAMES
  // ====================================

  getTimeframes() {
    return [...this.timeframes];
  }
}