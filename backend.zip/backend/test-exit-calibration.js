import CalibrationEngine from "./calibration/CalibrationEngine.js";

const strategySettingsOverride = {
  rsi: {
    enabled: true,
    period: 14,
    buyLevel: 35,
    sellLevel: 65,
    weight: 35
  },

  ema: {
    enabled: true,
    fast: 20,
    slow: 100,
    weight: 30
  },

  macd: {
    enabled: true,
    fast: 15,
    slow: 30,
    signal: 5,
    weight: 20
  },

  volume: {
    enabled: true,
    multiplier: 1.5,
    threshold: 100,
    weight: 15
  }
};

const config = {
  exchange: "TOOBIT",
  symbol: "BTCUSDT",
  timeframe: "15m",

  candleLimits: [470, 700, 1000, 1500],

  initialBalance: 10000,
  leverage: 1,

  feeRate: 0.0006,
  slippageRate: 0,

  stopLoss: {
    enabled: true,
    atrPeriod: 10,
    atrMultiplier: 1.7
  },

  takeProfit: {
    enabled: true,
    mode: "FIXED_RR",
    rrRatio: 1.5
  },

  trailing: {
    enabled: true,
    mode: "CHANDELIER",
    activationPercent: 0,
    atrPeriod: 30,
    atrMultiplier: 0.5,
    chandelierLookback: 60
  },

  positionSizing: {
    mode: "AUTO",
    positionSizePercent: 10,
    maxLossPerTrade: 2,
    riskPerTrade: 1,
    maxPositionSize: 100,
    minimumOrderSize: 10,
    minBalanceToTrade: 5
  },

  maxBarsInTrade: 0,

  strategySettingsOverride
};


// ============================================================
// BASIC RESULT
// ============================================================

function printResult(runNumber, result) {
  const m = result.metrics || {};

  console.log("----------------------------------------");
  console.log(`FINAL COMBINED RUN #${runNumber}`);
  console.log("----------------------------------------");

  console.log(
    `Net Profit       : ${(m.netProfit ?? 0).toFixed(4)}`
  );

  console.log(
    `Profit Factor    : ${(m.profitFactor ?? 0).toFixed(4)}`
  );

  console.log(
    `Win Rate         : ${(m.winRate ?? 0).toFixed(2)}%`
  );

  console.log(
    `Trades           : ${m.tradeCount ?? 0}`
  );

  console.log(
    `Expectancy       : ${(m.expectancy ?? 0).toFixed(4)}`
  );

  console.log(
    `Max Drawdown     : ${(m.maxDrawdown ?? 0).toFixed(4)}`
  );

  console.log(
    `Max DD %         : ${(m.maxDrawdownPercent ?? 0).toFixed(4)}%`
  );

  console.log(
    `Average Win      : ${(m.averageWin ?? 0).toFixed(4)}`
  );

  console.log(
    `Average Loss     : ${(m.averageLoss ?? 0).toFixed(4)}`
  );

  console.log(
    `Fees             : ${(m.totalFees ?? 0).toFixed(4)}`
  );

  console.log(
    `LONG             : ${m.longTrades ?? 0} | Win ${(m.longWinRate ?? 0).toFixed(2)}%`
  );

  console.log(
    `SHORT            : ${m.shortTrades ?? 0} | Win ${(m.shortWinRate ?? 0).toFixed(2)}%`
  );

  console.log("");
}


// ============================================================
// EXIT DIAGNOSTICS
// ============================================================

function printExitDiagnostics(runNumber, result) {
  const trades = Array.isArray(result.trades)
    ? result.trades
    : [];

  const exitReasons = [
    "TRAILING_STOP",
    "STOP_LOSS",
    "TAKE_PROFIT",
    "MAX_BARS",
    "END_OF_DATA"
  ];

  console.log("----------------------------------------");
  console.log(`EXIT DIAGNOSTICS RUN #${runNumber}`);
  console.log("----------------------------------------");

  for (const reason of exitReasons) {
    const reasonTrades = trades.filter(
      trade => trade.exitReason === reason
    );

    const wins = reasonTrades.filter(
      trade => Number(trade.netPnl ?? 0) > 0
    );

    const losses = reasonTrades.filter(
      trade => Number(trade.netPnl ?? 0) < 0
    );

    const totalPnl = reasonTrades.reduce(
      (total, trade) =>
        total + Number(trade.netPnl ?? 0),
      0
    );

    const averagePnl =
      reasonTrades.length > 0
        ? totalPnl / reasonTrades.length
        : 0;

    console.log("");
    console.log(`EXIT : ${reason}`);
    console.log(`Trades       : ${reasonTrades.length}`);
    console.log(`Wins         : ${wins.length}`);
    console.log(`Losses       : ${losses.length}`);
    console.log(`Total PnL    : ${totalPnl.toFixed(4)}`);
    console.log(`Average PnL  : ${averagePnl.toFixed(4)}`);
  }

  console.log("");
  console.log("SIDE DIAGNOSTICS");
  console.log("");

  for (const side of ["LONG", "SHORT"]) {
    const sideTrades = trades.filter(
      trade => trade.side === side
    );

    const wins = sideTrades.filter(
      trade => Number(trade.netPnl ?? 0) > 0
    );

    const losses = sideTrades.filter(
      trade => Number(trade.netPnl ?? 0) < 0
    );

    const totalPnl = sideTrades.reduce(
      (total, trade) =>
        total + Number(trade.netPnl ?? 0),
      0
    );

    const averagePnl =
      sideTrades.length > 0
        ? totalPnl / sideTrades.length
        : 0;

    console.log(
      `${side.padEnd(6)} : Trades ${sideTrades.length} | Wins ${wins.length} | Losses ${losses.length} | PnL ${totalPnl.toFixed(4)} | Avg ${averagePnl.toFixed(4)}`
    );
  }

  console.log("");
}


// ============================================================
// CHANDELIER TRADE STRUCTURE ANALYSIS
// ============================================================

function printChandelierTradeAnalysis(runNumber, result) {
  const trades = Array.isArray(result.trades)
    ? result.trades
    : [];

  const trailingTrades = trades.filter(
    trade =>
      trade.exitReason === "TRAILING_STOP"
  );

  console.log("----------------------------------------");
  console.log(
    `CHANDELIER TRADE STRUCTURE RUN #${runNumber}`
  );
  console.log("----------------------------------------");

  console.log(
    `Trailing trades : ${trailingTrades.length}`
  );

  if (trailingTrades.length === 0) {
    console.log("");
    console.log(
      "No TRAILING_STOP trades available."
    );
    console.log("");
    return;
  }

  let totalDistancePercent = 0;
  let validDistanceCount = 0;

  trailingTrades.forEach(
    (trade, index) => {

      const entryPrice =
        Number(trade.entryPrice ?? 0);

      const initialStop =
        Number(trade.initialStopLoss ?? 0);

      const finalTrailingStop =
        Number(trade.trailingStop ?? 0);

      const exitPrice =
        Number(
          trade.exitPrice ??
          finalTrailingStop ??
          0
        );

      const bars =
        Number(trade.barsInTrade ?? 0);

      const netPnl =
        Number(trade.netPnl ?? 0);

      let stopDistancePercent = null;

      if (
        Number.isFinite(entryPrice) &&
        entryPrice > 0 &&
        Number.isFinite(finalTrailingStop) &&
        finalTrailingStop > 0
      ) {
        if (trade.side === "LONG") {
          stopDistancePercent =
            (
              (entryPrice - finalTrailingStop) /
              entryPrice
            ) * 100;
        } else {
          stopDistancePercent =
            (
              (finalTrailingStop - entryPrice) /
              entryPrice
            ) * 100;
        }

        if (
          Number.isFinite(stopDistancePercent)
        ) {
          totalDistancePercent +=
            stopDistancePercent;

          validDistanceCount++;
        }
      }

      console.log("");
      console.log(
        `========== TRAILING TRADE #${index + 1} ==========`
      );

      console.log(
        `Side                 : ${trade.side}`
      );

      console.log(
        `Entry                : ${entryPrice.toFixed(4)}`
      );

      console.log(
        `Initial SL           : ${initialStop.toFixed(4)}`
      );

      console.log(
        `Final Chandelier     : ${
          Number.isFinite(finalTrailingStop) &&
          finalTrailingStop > 0
            ? finalTrailingStop.toFixed(4)
            : "N/A"
        }`
      );

      console.log(
        `Exit Price           : ${exitPrice.toFixed(4)}`
      );

      console.log(
        `Stop Distance        : ${
          Number.isFinite(stopDistancePercent)
            ? stopDistancePercent.toFixed(4) + "%"
            : "N/A"
        }`
      );

      console.log(
        `Bars In Trade        : ${bars}`
      );

      console.log(
        `Net PnL              : ${netPnl.toFixed(4)}`
      );

      console.log(
        `Result               : ${
          netPnl > 0
            ? "WIN"
            : netPnl < 0
              ? "LOSS"
              : "FLAT"
        }`
      );
    }
  );

  const averageDistancePercent =
    validDistanceCount > 0
      ? totalDistancePercent /
        validDistanceCount
      : 0;

  console.log("");
  console.log("----------------------------------------");
  console.log("CHANDELIER SUMMARY");
  console.log("----------------------------------------");

  console.log(
    `Trailing trades             : ${trailingTrades.length}`
  );

  console.log(
    `Valid stop distances        : ${validDistanceCount}`
  );

  console.log(
    `Average final stop distance : ${averageDistancePercent.toFixed(4)}%`
  );

  const wins = trailingTrades.filter(
    trade => Number(trade.netPnl ?? 0) > 0
  );

  const losses = trailingTrades.filter(
    trade => Number(trade.netPnl ?? 0) < 0
  );

  const averageWinningDistance =
    calculateAverageStopDistance(
      wins
    );

  const averageLosingDistance =
    calculateAverageStopDistance(
      losses
    );

  console.log(
    `Avg WIN stop distance       : ${averageWinningDistance.toFixed(4)}%`
  );

  console.log(
    `Avg LOSS stop distance      : ${averageLosingDistance.toFixed(4)}%`
  );

  console.log("");
}


// ============================================================
// AVERAGE STOP DISTANCE HELPER
// ============================================================

function calculateAverageStopDistance(trades) {
  if (!Array.isArray(trades) || trades.length === 0) {
    return 0;
  }

  let total = 0;
  let count = 0;

  for (const trade of trades) {
    const entryPrice =
      Number(trade.entryPrice ?? 0);

    const trailingStop =
      Number(trade.trailingStop ?? 0);

    if (
      !Number.isFinite(entryPrice) ||
      entryPrice <= 0 ||
      !Number.isFinite(trailingStop) ||
      trailingStop <= 0
    ) {
      continue;
    }

    let distance = 0;

    if (trade.side === "LONG") {
      distance =
        (
          (entryPrice - trailingStop) /
          entryPrice
        ) * 100;
    } else {
      distance =
        (
          (trailingStop - entryPrice) /
          entryPrice
        ) * 100;
    }

    if (Number.isFinite(distance)) {
      total += distance;
      count++;
    }
  }

  return count > 0
    ? total / count
    : 0;
}


// ============================================================
// CHANDELIER STRUCTURAL DIAGNOSTIC
// ============================================================

function printChandelierStructuralDiagnostic(runNumber, result) {
  const trades = Array.isArray(result.trades)
    ? result.trades
    : [];

  const trailingTrades = trades.filter(
    trade => trade.exitReason === "TRAILING_STOP"
  );

  console.log("----------------------------------------");
  console.log(
    `CHANDELIER STRUCTURAL DIAGNOSTIC RUN #${runNumber}`
  );
  console.log("----------------------------------------");

  console.log(
    `Trailing trades : ${trailingTrades.length}`
  );

  if (trailingTrades.length === 0) {
    console.log("");
    console.log(
      "No TRAILING_STOP trades available."
    );
    console.log("");
    return;
  }

  let totalInitialDistance = 0;
  let initialDistanceCount = 0;

  let totalFinalDistance = 0;
  let finalDistanceCount = 0;

  let totalTightening = 0;
  let tighteningCount = 0;

  const winners = [];
  const losers = [];

  for (const trade of trailingTrades) {
    const entryPrice =
      Number(trade.entryPrice ?? 0);

    const initialStop =
      Number(trade.initialStopLoss ?? 0);

    const finalTrailingStop =
      Number(trade.trailingStop ?? 0);

    const barsInTrade =
      Number(trade.barsInTrade ?? 0);

    const netPnl =
      Number(trade.netPnl ?? 0);

    if (
      !Number.isFinite(entryPrice) ||
      entryPrice <= 0
    ) {
      continue;
    }

    let initialDistance = null;
    let finalDistance = null;
    let tightening = null;

    if (
      Number.isFinite(initialStop) &&
      initialStop > 0
    ) {
      if (trade.side === "LONG") {
        initialDistance =
          (
            (entryPrice - initialStop) /
            entryPrice
          ) * 100;
      } else {
        initialDistance =
          (
            (initialStop - entryPrice) /
            entryPrice
          ) * 100;
      }
    }

    if (
      Number.isFinite(finalTrailingStop) &&
      finalTrailingStop > 0
    ) {
      if (trade.side === "LONG") {
        finalDistance =
          (
            (entryPrice - finalTrailingStop) /
            entryPrice
          ) * 100;
      } else {
        finalDistance =
          (
            (finalTrailingStop - entryPrice) /
            entryPrice
          ) * 100;
      }
    }

    if (
      Number.isFinite(initialDistance) &&
      Number.isFinite(finalDistance)
    ) {
      tightening =
        initialDistance - finalDistance;
    }

    if (Number.isFinite(initialDistance)) {
      totalInitialDistance += initialDistance;
      initialDistanceCount++;
    }

    if (Number.isFinite(finalDistance)) {
      totalFinalDistance += finalDistance;
      finalDistanceCount++;
    }

    if (Number.isFinite(tightening)) {
      totalTightening += tightening;
      tighteningCount++;
    }

    const diagnostic = {
      side: trade.side,
      entryPrice,
      initialStop,
      finalTrailingStop,
      initialDistance,
      finalDistance,
      tightening,
      barsInTrade,
      netPnl
    };

    if (netPnl > 0) {
      winners.push(diagnostic);
    } else if (netPnl < 0) {
      losers.push(diagnostic);
    }
  }

  const averageInitialDistance =
    initialDistanceCount > 0
      ? totalInitialDistance / initialDistanceCount
      : 0;

  const averageFinalDistance =
    finalDistanceCount > 0
      ? totalFinalDistance / finalDistanceCount
      : 0;

  const averageTightening =
    tighteningCount > 0
      ? totalTightening / tighteningCount
      : 0;

  console.log("");
  console.log("OVERALL");
  console.log("");

  console.log(
    `Average initial SL distance : ${averageInitialDistance.toFixed(4)}%`
  );

  console.log(
    `Average final Chandelier    : ${averageFinalDistance.toFixed(4)}%`
  );

  console.log(
    `Average stop tightening     : ${averageTightening.toFixed(4)}%`
  );

  console.log("");

  console.log("WINNING TRADES");
  console.log("");

  console.log(
    `Winning trailing trades     : ${winners.length}`
  );

  if (winners.length > 0) {
    const avgInitial =
      winners.reduce(
        (sum, trade) =>
          sum +
          Number(trade.initialDistance ?? 0),
        0
      ) / winners.length;

    const avgFinal =
      winners.reduce(
        (sum, trade) =>
          sum +
          Number(trade.finalDistance ?? 0),
        0
      ) / winners.length;

    const avgTightening =
      winners.reduce(
        (sum, trade) =>
          sum +
          Number(trade.tightening ?? 0),
        0
      ) / winners.length;

    const avgBars =
      winners.reduce(
        (sum, trade) =>
          sum +
          Number(trade.barsInTrade ?? 0),
        0
      ) / winners.length;

    console.log(
      `Avg initial distance      : ${avgInitial.toFixed(4)}%`
    );

    console.log(
      `Avg final distance        : ${avgFinal.toFixed(4)}%`
    );

    console.log(
      `Avg stop tightening       : ${avgTightening.toFixed(4)}%`
    );

    console.log(
      `Avg bars in trade         : ${avgBars.toFixed(2)}`
    );
  }

  console.log("");

  console.log("LOSING TRADES");
  console.log("");

  console.log(
    `Losing trailing trades      : ${losers.length}`
  );

  if (losers.length > 0) {
    const avgInitial =
      losers.reduce(
        (sum, trade) =>
          sum +
          Number(trade.initialDistance ?? 0),
        0
      ) / losers.length;

    const avgFinal =
      losers.reduce(
        (sum, trade) =>
          sum +
          Number(trade.finalDistance ?? 0),
        0
      ) / losers.length;

    const avgTightening =
      losers.reduce(
        (sum, trade) =>
          sum +
          Number(trade.tightening ?? 0),
        0
      ) / losers.length;

    const avgBars =
      losers.reduce(
        (sum, trade) =>
          sum +
          Number(trade.barsInTrade ?? 0),
        0
      ) / losers.length;

    console.log(
      `Avg initial distance      : ${avgInitial.toFixed(4)}%`
    );

    console.log(
      `Avg final distance        : ${avgFinal.toFixed(4)}%`
    );

    console.log(
      `Avg stop tightening       : ${avgTightening.toFixed(4)}%`
    );

    console.log(
      `Avg bars in trade         : ${avgBars.toFixed(2)}`
    );
  }

  console.log("");

  console.log("INDIVIDUAL TRADES");
  console.log("");

  for (const [index, trade] of trailingTrades.entries()) {
    const entryPrice =
      Number(trade.entryPrice ?? 0);

    const initialStop =
      Number(trade.initialStopLoss ?? 0);

    const finalTrailingStop =
      Number(trade.trailingStop ?? 0);

    const netPnl =
      Number(trade.netPnl ?? 0);

    const bars =
      Number(trade.barsInTrade ?? 0);

    let initialDistance = null;
    let finalDistance = null;
    let tightening = null;

    if (
      entryPrice > 0 &&
      initialStop > 0
    ) {
      initialDistance =
        trade.side === "LONG"
          ? (
              (entryPrice - initialStop) /
              entryPrice
            ) * 100
          : (
              (initialStop - entryPrice) /
              entryPrice
            ) * 100;
    }

    if (
      entryPrice > 0 &&
      finalTrailingStop > 0
    ) {
      finalDistance =
        trade.side === "LONG"
          ? (
              (entryPrice - finalTrailingStop) /
              entryPrice
            ) * 100
          : (
              (finalTrailingStop - entryPrice) /
              entryPrice
            ) * 100;
    }

    if (
      Number.isFinite(initialDistance) &&
      Number.isFinite(finalDistance)
    ) {
      tightening =
        initialDistance - finalDistance;
    }

    console.log(
      `#${index + 1} ${trade.side} | ` +
      `Bars ${bars} | ` +
      `Initial ${Number.isFinite(initialDistance) ? initialDistance.toFixed(4) : "N/A"}% | ` +
      `Final ${Number.isFinite(finalDistance) ? finalDistance.toFixed(4) : "N/A"}% | ` +
      `Tightening ${Number.isFinite(tightening) ? tightening.toFixed(4) : "N/A"}% | ` +
      `PnL ${netPnl.toFixed(4)}`
    );
  }

  console.log("");
  console.log("----------------------------------------");
  console.log("");
}


// ============================================================
// LOSING TRADE ANALYSIS
// ============================================================

function printChandelierLosingTrades(result) {
  const trades = Array.isArray(result.trades)
    ? result.trades
    : [];

  const losses = trades.filter(
    trade =>
      trade.exitReason === "TRAILING_STOP" &&
      Number(trade.netPnl ?? 0) < 0
  );

  console.log("----------------------------------------");
  console.log("CHANDELIER LOSING TRADE ANALYSIS");
  console.log("----------------------------------------");

  console.log(
    `Trailing losses : ${losses.length}`
  );

  if (losses.length === 0) {
    console.log("");
    console.log(
      "No losing TRAILING_STOP trades found."
    );
    console.log("");
    return;
  }

  losses.forEach(
    (trade, index) => {

      const entryPrice =
        Number(trade.entryPrice ?? 0);

      const trailingStop =
        Number(trade.trailingStop ?? 0);

      const exitPrice =
        Number(trade.exitPrice ?? 0);

      const bars =
        Number(trade.barsInTrade ?? 0);

      console.log("");
      console.log(
        `========== LOSING TRAILING TRADE #${index + 1} ==========`
      );

      console.log(
        `Side                 : ${trade.side}`
      );

      console.log(
        `Entry                : ${entryPrice.toFixed(4)}`
      );

      console.log(
        `Final Chandelier     : ${
          trailingStop > 0
            ? trailingStop.toFixed(4)
            : "N/A"
        }`
      );

      console.log(
        `Exit Price           : ${exitPrice.toFixed(4)}`
      );

      console.log(
        `Bars In Trade        : ${bars}`
      );

      console.log(
        `Net PnL              : ${Number(
          trade.netPnl ?? 0
        ).toFixed(4)}`
      );

      console.log(
        `Confidence           : ${Number(
          trade.signalConfidence ?? 0
        ).toFixed(2)}`
      );

      console.log(
        `Signal Score         : ${Number(
          trade.signalScore ?? 0
        ).toFixed(4)}`
      );

      console.log(
        `Buy Score            : ${Number(
          trade.buyScore ?? 0
        ).toFixed(4)}`
      );

      console.log(
        `Sell Score           : ${Number(
          trade.sellScore ?? 0
        ).toFixed(4)}`
      );

      console.log(
        `RSI Conflict         : ${
          trade.signalDetails?.conflictWithRSI === true
            ? "YES"
            : "NO"
        }`
      );

      console.log("");
      console.log("SIGNAL DETAILS");

      try {
        console.log(
          JSON.stringify(
            trade.signalDetails ?? null,
            null,
            2
          )
        );
      } catch (error) {
        console.log(
          "Unable to serialize signal details:"
        );

        console.log(error);
      }
    }
  );

  console.log("");
}


// ============================================================
// STOP LOSS TRADE DETAILS
// ============================================================

function printStopLossTradeDetails(result) {
  const trades = Array.isArray(result.trades)
    ? result.trades
    : [];

  const stopTrades = trades.filter(
    trade => trade.exitReason === "STOP_LOSS"
  );

  console.log("----------------------------------------");
  console.log("STOP LOSS TRADE DETAILS");
  console.log("----------------------------------------");

  console.log(
    `STOP_LOSS trades : ${stopTrades.length}`
  );

  if (stopTrades.length === 0) {
    console.log("");
    console.log("No STOP_LOSS trades found.");
    console.log("");
    return;
  }

  stopTrades.forEach(
    (trade, index) => {

      console.log("");
      console.log(
        `========== STOP LOSS #${index + 1} ==========`
      );

      try {
        console.log(
          JSON.stringify(
            trade,
            null,
            2
          )
        );
      } catch (error) {
        console.log(
          "Unable to serialize trade object:"
        );

        console.log(error);
      }
    }
  );

  console.log("");
  console.log("----------------------------------------");
  console.log("");
}


// ============================================================
// STOP LOSS STRUCTURE ANALYSIS
// ============================================================

function printStopLossStructureAnalysis(result) {
  const trades = Array.isArray(result.trades)
    ? result.trades
    : [];

  const stopTrades = trades.filter(
    trade => trade.exitReason === "STOP_LOSS"
  );

  console.log("----------------------------------------");
  console.log("STOP LOSS STRUCTURE ANALYSIS");
  console.log("----------------------------------------");

  console.log(
    `Total STOP_LOSS trades : ${stopTrades.length}`
  );

  if (stopTrades.length === 0) {
    console.log("");
    console.log("No STOP_LOSS trades available.");
    console.log("");
    return;
  }

  const groups = [
    {
      name: "1-2 bars",
      min: 1,
      max: 2
    },
    {
      name: "3-5 bars",
      min: 3,
      max: 5
    },
    {
      name: "6-10 bars",
      min: 6,
      max: 10
    },
    {
      name: "11-20 bars",
      min: 11,
      max: 20
    },
    {
      name: "21+ bars",
      min: 21,
      max: Infinity
    }
  ];

  for (const group of groups) {
    const groupTrades = stopTrades.filter(
      trade => {

        const bars = Number(
          trade.barsInTrade ?? 0
        );

        return (
          bars >= group.min &&
          bars <= group.max
        );
      }
    );

    const longCount = groupTrades.filter(
      trade => trade.side === "LONG"
    ).length;

    const shortCount = groupTrades.filter(
      trade => trade.side === "SHORT"
    ).length;

    const totalPnl = groupTrades.reduce(
      (total, trade) =>
        total + Number(trade.netPnl ?? 0),
      0
    );

    const averagePnl =
      groupTrades.length > 0
        ? totalPnl / groupTrades.length
        : 0;

    const averageConfidence =
      groupTrades.length > 0
        ? groupTrades.reduce(
            (total, trade) =>
              total +
              Number(
                trade.signalConfidence ?? 0
              ),
            0
          ) / groupTrades.length
        : 0;

    const averageAtr =
      groupTrades.length > 0
        ? groupTrades.reduce(
            (total, trade) =>
              total +
              Number(
                trade.atr ?? 0
              ),
            0
          ) / groupTrades.length
        : 0;

    const conflictCount = groupTrades.filter(
      trade =>
        trade.signalDetails?.conflictWithRSI === true
    ).length;

    const conflictPercent =
      groupTrades.length > 0
        ? (
            conflictCount /
            groupTrades.length
          ) * 100
        : 0;

    const highConfidenceCount =
      groupTrades.filter(
        trade =>
          Number(
            trade.signalConfidence ?? 0
          ) >= 80
      ).length;

    const highConfidencePercent =
      groupTrades.length > 0
        ? (
            highConfidenceCount /
            groupTrades.length
          ) * 100
        : 0;

    console.log("");
    console.log(`GROUP : ${group.name}`);
    console.log(
      `Trades             : ${groupTrades.length}`
    );
    console.log(
      `LONG               : ${longCount}`
    );
    console.log(
      `SHORT              : ${shortCount}`
    );
    console.log(
      `Total PnL          : ${totalPnl.toFixed(4)}`
    );
    console.log(
      `Average PnL        : ${averagePnl.toFixed(4)}`
    );
    console.log(
      `Avg Confidence     : ${averageConfidence.toFixed(2)}`
    );
    console.log(
      `Avg ATR            : ${averageAtr.toFixed(4)}`
    );
    console.log(
      `RSI Conflict       : ${conflictCount} (${conflictPercent.toFixed(2)}%)`
    );
    console.log(
      `Confidence >= 80   : ${highConfidenceCount} (${highConfidencePercent.toFixed(2)}%)`
    );
  }

  console.log("");
  console.log("STOP LOSS SIDE ANALYSIS");
  console.log("");

  for (const side of ["LONG", "SHORT"]) {
    const sideTrades = stopTrades.filter(
      trade => trade.side === side
    );

    const totalPnl = sideTrades.reduce(
      (total, trade) =>
        total + Number(trade.netPnl ?? 0),
      0
    );

    const averageBars =
      sideTrades.length > 0
        ? sideTrades.reduce(
            (total, trade) =>
              total +
              Number(
                trade.barsInTrade ?? 0
              ),
            0
          ) / sideTrades.length
        : 0;

    const averageConfidence =
      sideTrades.length > 0
        ? sideTrades.reduce(
            (total, trade) =>
              total +
              Number(
                trade.signalConfidence ?? 0
              ),
            0
          ) / sideTrades.length
        : 0;

    const conflictCount = sideTrades.filter(
      trade =>
        trade.signalDetails?.conflictWithRSI === true
    ).length;

    console.log(
      `${side.padEnd(6)} : Trades ${sideTrades.length} | PnL ${totalPnl.toFixed(4)} | Avg Bars ${averageBars.toFixed(2)} | Avg Confidence ${averageConfidence.toFixed(2)} | Conflicts ${conflictCount}`
    );
  }

  console.log("");
  console.log("STOP LOSS CONFIDENCE ANALYSIS");
  console.log("");

  const confidenceGroups = [
    {
      name: "0-49",
      min: 0,
      max: 49
    },
    {
      name: "50-69",
      min: 50,
      max: 69
    },
    {
      name: "70-79",
      min: 70,
      max: 79
    },
    {
      name: "80-89",
      min: 80,
      max: 89
    },
    {
      name: "90-100",
      min: 90,
      max: 100
    }
  ];

  for (const group of confidenceGroups) {
    const groupTrades = stopTrades.filter(
      trade => {

        const confidence = Number(
          trade.signalConfidence ?? 0
        );

        return (
          confidence >= group.min &&
          confidence <= group.max
        );
      }
    );

    const totalPnl = groupTrades.reduce(
      (total, trade) =>
        total + Number(trade.netPnl ?? 0),
      0
    );

    const averagePnl =
      groupTrades.length > 0
        ? totalPnl / groupTrades.length
        : 0;

    console.log(
      `${group.name.padEnd(7)} : Trades ${groupTrades.length} | PnL ${totalPnl.toFixed(4)} | Avg ${averagePnl.toFixed(4)}`
    );
  }

  const conflictTrades = stopTrades.filter(
    trade =>
      trade.signalDetails?.conflictWithRSI === true
  );

  const nonConflictTrades = stopTrades.filter(
    trade =>
      trade.signalDetails?.conflictWithRSI !== true
  );

  const conflictPnl = conflictTrades.reduce(
    (total, trade) =>
      total + Number(trade.netPnl ?? 0),
    0
  );

  const nonConflictPnl =
    nonConflictTrades.reduce(
      (total, trade) =>
        total + Number(trade.netPnl ?? 0),
      0
    );

  console.log("");
  console.log("RSI CONFLICT ANALYSIS");
  console.log("");

  console.log(
    `Conflict trades     : ${conflictTrades.length} | PnL ${conflictPnl.toFixed(4)}`
  );

  console.log(
    `Non-conflict trades : ${nonConflictTrades.length} | PnL ${nonConflictPnl.toFixed(4)}`
  );

  console.log("");
  console.log("----------------------------------------");
  console.log("");
}


// ============================================================
// TRAILING STOP SIDE DIAGNOSTICS
// ============================================================

function printTrailingSideDiagnostics(runNumber, result) {
  const trades = Array.isArray(result.trades)
    ? result.trades
    : [];

  console.log("----------------------------------------");
  console.log(
    `TRAILING STOP SIDE DIAGNOSTICS RUN #${runNumber}`
  );
  console.log("----------------------------------------");

  for (const side of ["LONG", "SHORT"]) {
    const trailingTrades = trades.filter(
      trade =>
        trade.exitReason === "TRAILING_STOP" &&
        trade.side === side
    );

    const totalPnl = trailingTrades.reduce(
      (total, trade) =>
        total + Number(trade.netPnl ?? 0),
      0
    );

    const wins = trailingTrades.filter(
      trade => Number(trade.netPnl ?? 0) > 0
    );

    const losses = trailingTrades.filter(
      trade => Number(trade.netPnl ?? 0) < 0
    );

    console.log("");
    console.log(`SIDE : ${side}`);
    console.log(`Trades       : ${trailingTrades.length}`);
    console.log(`Wins         : ${wins.length}`);
    console.log(`Losses       : ${losses.length}`);
    console.log(`Total PnL    : ${totalPnl.toFixed(4)}`);

    if (trailingTrades.length > 0) {
      console.log(
        `Average PnL  : ${(totalPnl / trailingTrades.length).toFixed(4)}`
      );
    } else {
      console.log("Average PnL  : 0.0000");
    }
  }

  console.log("");
}


// ============================================================
// TRADE COUNT DIAGNOSTICS
// ============================================================

function printTradeStructure(runNumber, result) {
  const trades = Array.isArray(result.trades)
    ? result.trades
    : [];

  console.log("----------------------------------------");
  console.log(`TRADE STRUCTURE RUN #${runNumber}`);
  console.log("----------------------------------------");

  console.log(
    `Total trades       : ${trades.length}`
  );

  const longTrades = trades.filter(
    trade => trade.side === "LONG"
  );

  const shortTrades = trades.filter(
    trade => trade.side === "SHORT"
  );

  const trailingTrades = trades.filter(
    trade => trade.exitReason === "TRAILING_STOP"
  );

  const stopTrades = trades.filter(
    trade => trade.exitReason === "STOP_LOSS"
  );

  const tpTrades = trades.filter(
    trade => trade.exitReason === "TAKE_PROFIT"
  );

  console.log(
    `LONG trades        : ${longTrades.length}`
  );

  console.log(
    `SHORT trades       : ${shortTrades.length}`
  );

  console.log(
    `Trailing exits     : ${trailingTrades.length}`
  );

  console.log(
    `Stop-loss exits    : ${stopTrades.length}`
  );

  console.log(
    `Take-profit exits  : ${tpTrades.length}`
  );

  console.log("");
}


// ============================================================
// CONFIG DIAGNOSTICS
// ============================================================

function printConfigDiagnostics() {
  console.log("========================================");
  console.log("     FINAL COMBINED TEST CONFIGURATION");
  console.log("========================================");

  console.log(
    `Exchange           : ${config.exchange}`
  );

  console.log(
    `Symbol             : ${config.symbol}`
  );

  console.log(
    `Timeframe          : ${config.timeframe}`
  );

  console.log(
    `Candle Limits      : ${config.candleLimits.join(", ")}`
  );

  console.log(
    `Initial Balance    : ${config.initialBalance}`
  );

  console.log(
    `Leverage           : ${config.leverage}`
  );

  console.log(
    `Fee Rate           : ${config.feeRate}`
  );

  console.log("");

  console.log("STOP LOSS");
  console.log(
    `Enabled            : ${config.stopLoss.enabled}`
  );

  console.log(
    `ATR Period         : ${config.stopLoss.atrPeriod}`
  );

  console.log(
    `ATR Multiplier     : ${config.stopLoss.atrMultiplier}`
  );

  console.log("");

  console.log("TAKE PROFIT");
  console.log(
    `Enabled            : ${config.takeProfit.enabled}`
  );

  console.log(
    `Mode               : ${config.takeProfit.mode}`
  );

  console.log(
    `RR Ratio           : ${config.takeProfit.rrRatio}`
  );

  console.log("");

  console.log("TRAILING");
  console.log(
    `Enabled            : ${config.trailing.enabled}`
  );

  console.log(
    `Mode               : ${config.trailing.mode}`
  );

  console.log(
    `Activation         : ${config.trailing.activationPercent}%`
  );

  console.log(
    `ATR Period         : ${config.trailing.atrPeriod}`
  );

  console.log(
    `ATR Multiplier     : ${config.trailing.atrMultiplier}`
  );

  console.log(
    `Lookback           : ${config.trailing.chandelierLookback}`
  );

  console.log("");

  console.log("STRATEGY");
  console.log(
    `RSI                : ${config.strategySettingsOverride.rsi.enabled}`
  );

  console.log(
    `EMA                : ${config.strategySettingsOverride.ema.enabled}`
  );

  console.log(
    `MACD               : ${config.strategySettingsOverride.macd.enabled}`
  );

  console.log(
    `Volume             : ${config.strategySettingsOverride.volume.enabled}`
  );

  console.log("========================================");
  console.log("");
}


// ============================================================
// COMPARE RESULTS
// ============================================================

function compareResults(first, second) {
  const a = first.metrics || {};
  const b = second.metrics || {};

  const fields = [
    ["Net Profit", a.netProfit, b.netProfit],
    ["Profit Factor", a.profitFactor, b.profitFactor],
    ["Win Rate", a.winRate, b.winRate],
    ["Trades", a.tradeCount, b.tradeCount],
    ["Expectancy", a.expectancy, b.expectancy],
    ["Max Drawdown", a.maxDrawdown, b.maxDrawdown],
    ["Max DD %", a.maxDrawdownPercent, b.maxDrawdownPercent],
    ["Average Win", a.averageWin, b.averageWin],
    ["Average Loss", a.averageLoss, b.averageLoss],
    ["Fees", a.totalFees, b.totalFees],
    ["LONG Trades", a.longTrades, b.longTrades],
    ["LONG Win Rate", a.longWinRate, b.longWinRate],
    ["SHORT Trades", a.shortTrades, b.shortTrades],
    ["SHORT Win Rate", a.shortWinRate, b.shortWinRate]
  ];

  let identical = true;

  console.log("========================================");
  console.log("   FINAL COMBINED REPRODUCIBILITY");
  console.log("========================================");

  for (const [name, valueA, valueB] of fields) {
    const aNumber = Number(valueA ?? 0);
    const bNumber = Number(valueB ?? 0);
    const same = aNumber === bNumber;

    if (!same) {
      identical = false;
    }

    console.log(
      `${name.padEnd(18)} : ${aNumber} | ${bNumber} | ${same ? "MATCH" : "DIFFERENT"}`
    );
  }

  console.log("");

  if (identical) {
    console.log("RESULT : IDENTICAL");
    console.log(
      "Final Combined Calibration is reproducible for this configuration."
    );
  } else {
    console.log("RESULT : DIFFERENT");
    console.log(
      "Final Combined Calibration is NOT reproducible for this configuration."
    );
  }

  console.log("========================================");
}


// ============================================================
// MAIN
// ============================================================

async function main() {
  console.log("");
  console.log("========================================");
  console.log("   MULTI-RANGE FINAL CALIBRATION TEST");
  console.log("========================================");
  console.log("");

  console.log(
    "Same calibration configuration will be tested"
  );

  console.log(
    "across multiple historical candle ranges."
  );

  console.log(
    "No strategy parameter is changed between ranges."
  );

  console.log("");

  printConfigDiagnostics();

  console.log("========================================");
  console.log("       CURRENT CALIBRATION");
  console.log("========================================");

  console.log("RSI                : 35 / 65");
  console.log("EMA                : 20 / 100");
  console.log("MACD               : 15 / 30 / 5");
  console.log("Volume             : 1.5");

  console.log("");

  console.log("SL ATR Period      : 10");
  console.log("SL ATR Multiplier  : 1.7");

  console.log("");

  console.log("TP Mode            : FIXED_RR");
  console.log("TP RR              : 1.5");

  console.log("");

  console.log("Trailing Mode      : CHANDELIER");
  console.log("Trailing ATR       : 30");
  console.log("Lookback           : 60");
  console.log("Multiplier         : 0.5");
  console.log("Activation         : 0%");

  console.log("");

  console.log(
    `Historical ranges : ${config.candleLimits.join(", ")}`
  );

  console.log("");
  console.log("========================================");
  console.log("");

  for (const candleLimit of config.candleLimits) {

    const rangeConfig = {
      ...config,
      candleLimit
    };

    console.log("");
    console.log("========================================");
    console.log(
      `     HISTORICAL RANGE : ${candleLimit}`
    );
    console.log("========================================");
    console.log("");

    console.log(
      `Candle Limit       : ${candleLimit}`
    );

    console.log(
      "Configuration      : IDENTICAL"
    );

    console.log("");

    // --------------------------------------------------------
    // RUN #1
    // --------------------------------------------------------

    console.log("----------------------------------------");
    console.log(
      `RUN #1 — ${candleLimit} CANDLES`
    );
    console.log("----------------------------------------");

    const result1 =
      await CalibrationEngine.run(rangeConfig);

    printResult(
      1,
      result1
    );

    printExitDiagnostics(
      1,
      result1
    );

    printChandelierTradeAnalysis(
      1,
      result1
    );

    printChandelierLosingTrades(
      result1
    );

    printTrailingSideDiagnostics(
      1,
      result1
    );

    printTradeStructure(
      1,
      result1
    );

    printChandelierStructuralDiagnostic(
      1,
      result1
    );

    printStopLossTradeDetails(
      result1
    );

    printStopLossStructureAnalysis(
      result1
    );

    // --------------------------------------------------------
    // RUN #2
    // --------------------------------------------------------

    console.log("----------------------------------------");
    console.log(
      `RUN #2 — ${candleLimit} CANDLES`
    );
    console.log("----------------------------------------");

    const result2 =
      await CalibrationEngine.run(rangeConfig);

    printResult(
      2,
      result2
    );

    printExitDiagnostics(
      2,
      result2
    );

    printChandelierTradeAnalysis(
      2,
      result2
    );

    printChandelierLosingTrades(
      result2
    );

    printTrailingSideDiagnostics(
      2,
      result2
    );

    printTradeStructure(
      2,
      result2
    );

    printChandelierStructuralDiagnostic(
      2,
      result2
    );

    printStopLossTradeDetails(
      result2
    );

    printStopLossStructureAnalysis(
      result2
    );

    // --------------------------------------------------------
    // REPRODUCIBILITY
    // --------------------------------------------------------

    console.log("----------------------------------------");
    console.log(
      `REPRODUCIBILITY — ${candleLimit} CANDLES`
    );
    console.log("----------------------------------------");

    compareResults(
      result1,
      result2
    );

    console.log("");
    console.log(
      `Completed historical range: ${candleLimit}`
    );
    console.log("");
  }

  console.log("");
  console.log("========================================");
  console.log(" MULTI-RANGE CALIBRATION TEST COMPLETE");
  console.log("========================================");
  console.log("");

  console.log(
    "No calibration parameter was changed."
  );

  console.log(
    "Structural Chandelier diagnostics completed."
  );

  console.log(
    "Results above must be compared across ranges."
  );

  console.log("");
}


// ============================================================
// ERROR HANDLER
// ============================================================

main().catch(
  (error) => {

    console.error("");

    console.error(
      "Final Combined Calibration test failed:"
    );

    console.error(
      error
    );

    process.exit(1);

  }
);