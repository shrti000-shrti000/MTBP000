import CalibrationEngine from "./calibration/CalibrationEngine.js";

const baseSettings = {
    rsi: {
        enabled: true,
        period: 14,
        buyLevel: 35,
        sellLevel: 65,
        weight: 35
    },

    ema: {
        enabled: true,
        fast: 20,
        slow: 100,
        weight: 30
    },

    macd: {
        enabled: true,
        fast: 15,
        slow: 30,
        signal: 5,
        weight: 20
    },

    volume: {
        enabled: true,
        multiplier: 1.5,
        threshold: 100,
        weight: 15
    }
};

const multipliers = [1.5];

const thresholds = [50, 75, 100, 125, 150];

console.log("\n========================================");
console.log("   VOLUME THRESHOLD CALIBRATION");
console.log("========================================\n");

for (const multiplier of multipliers) {

    for (const threshold of thresholds) {

        const strategySettingsOverride = {
            ...baseSettings,

            volume: {
                ...baseSettings.volume,
                multiplier,
                threshold
            }
        };

        const result = await CalibrationEngine.run({
            strategySettingsOverride
        });

        const m = result.metrics || {};

        console.log(
            `Multiplier ${multiplier.toFixed(1)} | ` +
            `Threshold ${threshold} | ` +
            `Net ${Number(m.netProfit || 0).toFixed(4)} | ` +
            `PF ${Number(m.profitFactor || 0).toFixed(4)} | ` +
            `Win ${Number(m.winRate || 0).toFixed(2)}% | ` +
            `Trades ${m.tradeCount || 0} | ` +
            `Exp ${Number(m.expectancy || 0).toFixed(4)} | ` +
            `DD ${Number(m.maxDrawdownPercent || 0).toFixed(4)}% | ` +
            `Fees ${Number(m.totalFees || 0).toFixed(4)}`
        );
    }
}

console.log("\n========================================");
console.log("Volume threshold calibration finished.");
console.log("========================================\n");