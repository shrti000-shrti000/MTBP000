import PositionStore from "../risk/PositionStore.js";

const testPosition = PositionStore.add({

    exchange: "TOOBIT",

    symbol: "BTCUSDT",

    action: "OPEN",

    side: "LONG",

    entryPrice: 64000,

    quantity: 1,

    leverage: 1,

    stopLoss: 63000,

    takeProfit: 66000,

    trailing: true,

    orderType: "MARKET",

    timeframe: "1m",

    confidence: 80,

    signalId: null,

});

console.log("🟢 TEST LIVE POSITION CREATED");

console.log(testPosition);