import PostgresAdapter from "../storage/database/PostgresAdapter.js";

console.log("🗑️ DELETE TEST POSITION");

try {

    const rows =
        await PostgresAdapter.findAll(
            "positions"
        );


    const testPosition =
        rows.find(
            p =>
            p.position_code === "TEST-POS-001"
        );


    if (!testPosition) {

        console.log(
            "❌ TEST POSITION NOT FOUND"
        );

        process.exit(0);

    }


    await PostgresAdapter.remove(
        "positions",
        testPosition.id
    );


    console.log(
        "✅ TEST POSITION DELETED:",
        testPosition.id
    );


    process.exit(0);


}
catch(error) {

    console.error(
        "❌ DELETE FAILED:",
        error.message
    );

    process.exit(1);

}