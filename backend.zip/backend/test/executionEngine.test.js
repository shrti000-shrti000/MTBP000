// ==========================================================
// MTBP - REAL EXECUTION ENGINE TEST
// ==========================================================
//
// هدف:
//
// TEST 1
// Bot STOPPED
// → باید توسط BOT_STOPPED متوقف شود.
//
// TEST 2
// Bot RUNNING
// Exchange STOPPED
// → باید توسط Exchange Gate متوقف شود.
//
// TEST 3
// Bot RUNNING
// Exchange RUNNING
// Exchange ENABLED
// Live Trading ENABLED
// → باید از Gateهای ExecutionEngine عبور کند.
//
// TEST 4
// اجرای واقعی OrderExecutor
// → سفارش واقعی به Toobit ارسال می‌شود.
// → پاسخ واقعی Exchange چاپ می‌شود.
//
// ==========================================================


import ExecutionEngine
    from "../execution/ExecutionEngine.js";

import BotController
    from "../core/BotController.js";

import ExchangeStateManager
    from "../exchange/ExchangeStateManager.js";

import LiveTradingManager
    from "../config/LiveTradingManager.js";


// ==========================================================
// TEST CONFIG
// ==========================================================

const exchange =
    "TOOBIT";

const symbol =
    "BTCUSDT";


// ==========================================================
// TEST SIGNAL
// ==========================================================

const signal = {

    id:
        `TEST_REAL_${Date.now()}`,

    exchange,

    symbol,

    action:
        "OPEN",

    side:
        "LONG",

    confidence:
        80,

    timeframe:
        "1m"

};


// ==========================================================
// TEST RISK PLAN
// ==========================================================

const riskPlan = {

    exchange,

    quantity:
        0.001,

    orderType:
        "MARKET",

    leverage:
        1,

    stopLoss:
        null,

    takeProfit:
        null,

    trailing:
        null

};


// ==========================================================
// PRINT RESULT
// ==========================================================

function printResult(
    title,
    result
) {

    console.log(
        "\n=================================================="
    );

    console.log(
        title
    );

    console.log(
        "=================================================="
    );

    console.dir(
        result,
        {
            depth:
                null
        }
    );

}


// ==========================================================
// PRINT EXCHANGE STATE
// ==========================================================

function printExchangeState() {

    console.log(
        "\n🔎 CURRENT EXCHANGE STATE:"
    );

    console.dir(
        ExchangeStateManager.getState(
            exchange
        ),
        {
            depth:
                null
        }
    );

}


// ==========================================================
// PRINT LIVE TRADING STATE
// ==========================================================

function printLiveTradingState() {

    console.log(
        "\n🔎 CURRENT LIVE TRADING STATE:"
    );

    console.dir(
        LiveTradingManager.getState(),
        {
            depth:
                null
        }
    );

}


// ==========================================================
// TEST 1
// BOT STOPPED
// ==========================================================

async function test1BotStopped() {

    console.log(
        "\n\n🧪 TEST 1"
    );

    console.log(
        "BOT STOPPED → EXECUTION MUST BE BLOCKED"
    );


    // ----------------------------------------------
    // Bot STOPPED
    // ----------------------------------------------

    BotController.stop();


    // ----------------------------------------------
    // Exchange وضعیت مناسب
    // ----------------------------------------------

    ExchangeStateManager.enable(
        exchange
    );

    ExchangeStateManager.setStatus(
        exchange,
        "RUNNING"
    );


    printExchangeState();


    const result =
        await ExecutionEngine.execute(
            signal,
            riskPlan
        );


    printResult(
        "TEST 1 RESULT",
        result
    );


    if (
        result.blocked === true &&
        result.reason === "BOT_STOPPED"
    ) {

        console.log(
            "\n✅ TEST 1 PASSED"
        );

        console.log(
            "Bot Gate correctly blocked execution."
        );

    }
    else {

        console.log(
            "\n❌ TEST 1 FAILED"
        );

        console.log(
            "Expected reason: BOT_STOPPED"
        );

    }

}


// ==========================================================
// TEST 2
// BOT RUNNING
// EXCHANGE STOPPED
// ==========================================================

async function test2ExchangeStopped() {

    console.log(
        "\n\n🧪 TEST 2"
    );

    console.log(
        "BOT RUNNING + EXCHANGE STOPPED"
    );


    // ----------------------------------------------
    // Bot RUNNING
    // ----------------------------------------------

    BotController.start();


    // ----------------------------------------------
    // Exchange ENABLED
    // ولی STOPPED
    // ----------------------------------------------

    ExchangeStateManager.enable(
        exchange
    );

    ExchangeStateManager.setStatus(
        exchange,
        "STOPPED"
    );


    printExchangeState();


    const result =
        await ExecutionEngine.execute(
            signal,
            riskPlan
        );


    printResult(
        "TEST 2 RESULT",
        result
    );


    if (
        result.blocked === true &&
        String(result.reason)
            .startsWith("EXCHANGE_")
    ) {

        console.log(
            "\n✅ TEST 2 PASSED"
        );

        console.log(
            "Exchange Gate correctly blocked execution."
        );

        console.log(
            "Reason:",
            result.reason
        );

    }
    else {

        console.log(
            "\n❌ TEST 2 FAILED"
        );

        console.log(
            "Expected an EXCHANGE_* blocking reason."
        );

    }

}


// ==========================================================
// TEST 3
// ALL GATES BEFORE LIVE MODE
// ==========================================================

async function test3AllGatesOpen() {

    console.log(
        "\n\n🧪 TEST 3"
    );

    console.log(
        "ALL BOT + EXCHANGE + LIVE GATES OPEN"
    );


    // ----------------------------------------------
    // BOT RUNNING
    // ----------------------------------------------

    BotController.start();


    // ----------------------------------------------
    // EXCHANGE ENABLED
    // ----------------------------------------------

    ExchangeStateManager.enable(
        exchange
    );


    // ----------------------------------------------
    // EXCHANGE RUNNING
    // ----------------------------------------------

    ExchangeStateManager.setStatus(
        exchange,
        "RUNNING"
    );


    // ----------------------------------------------
    // LIVE TRADING ENABLED
    // ----------------------------------------------

    LiveTradingManager.enable();


    // ----------------------------------------------
    // EMERGENCY STOP OFF
    // ----------------------------------------------

    LiveTradingManager.setEmergencyStop(
        false
    );


    // ----------------------------------------------
    // LONG ALLOWED
    // ----------------------------------------------

    LiveTradingManager.allowLong(
        true
    );


    // ----------------------------------------------
    // PRINT STATES
    // ----------------------------------------------

    printExchangeState();

    printLiveTradingState();


    const result =
        await ExecutionEngine.execute(
            signal,
            riskPlan
        );


    printResult(
        "TEST 3 RESULT",
        result
    );


    // ----------------------------------------------
    // اگر دوباره Live Mode بسته بود
    // ----------------------------------------------

    if (
        result.reason ===
        "LIVE_MODE_DISABLED"
    ) {

        console.log(
            "\n❌ TEST 3 FAILED"
        );

        console.log(
            "Live Trading is still disabled."
        );

        return;

    }


    // ----------------------------------------------
    // اگر Exchange Gate بسته بود
    // ----------------------------------------------

    if (
        result.reason &&
        String(result.reason)
            .startsWith("EXCHANGE_")
    ) {

        console.log(
            "\n❌ TEST 3 FAILED"
        );

        console.log(
            "Exchange Gate is still blocking execution."
        );

        console.log(
            "Reason:",
            result.reason
        );

        return;

    }


    // ----------------------------------------------
    // اگر Bot Gate بسته بود
    // ----------------------------------------------

    if (
        result.reason ===
        "BOT_STOPPED"
    ) {

        console.log(
            "\n❌ TEST 3 FAILED"
        );

        console.log(
            "Bot Gate is still blocking execution."
        );

        return;

    }


    console.log(
        "\n🟢 TEST 3 PASSED GATES"
    );

    console.log(
        "Bot + Exchange + Live Trading gates are open."
    );

}


// ==========================================================
// TEST 4
// REAL TOOBIT EXECUTION
// ==========================================================
//
// هشدار بسیار مهم:
//
// این تست سفارش واقعی ارسال می‌کند.
//
// هیچ Mock استفاده نمی‌شود.
//
// ==========================================================

async function test4RealExecution() {

    console.log(
        "\n\n🧪 TEST 4"
    );

    console.log(
        "🔥 REAL TOOBIT ORDER EXECUTION"
    );

    console.log(
        "=================================================="
    );

    console.log(
        "Exchange:",
        exchange
    );

    console.log(
        "Symbol:",
        symbol
    );

    console.log(
        "Side:",
        "LONG"
    );

    console.log(
        "Quantity:",
        riskPlan.quantity
    );

    console.log(
        "Order Type:",
        riskPlan.orderType
    );


    // ==================================================
    // BOT RUNNING
    // ==================================================

    BotController.start();


    // ==================================================
    // EXCHANGE ENABLED
    // ==================================================

    ExchangeStateManager.enable(
        exchange
    );


    // ==================================================
    // EXCHANGE RUNNING
    // ==================================================

    ExchangeStateManager.setStatus(
        exchange,
        "RUNNING"
    );


    // ==================================================
    // LIVE TRADING ENABLED
    // ==================================================

    LiveTradingManager.enable();


    // ==================================================
    // EMERGENCY STOP OFF
    // ==================================================

    LiveTradingManager.setEmergencyStop(
        false
    );


    // ==================================================
    // LONG ALLOWED
    // ==================================================

    LiveTradingManager.allowLong(
        true
    );


    // ==================================================
    // PRINT CURRENT STATES
    // ==================================================

    printExchangeState();

    printLiveTradingState();


    // ==================================================
    // FINAL WARNING
    // ==================================================

    console.log(
        "\n🚨 REAL ORDER WILL BE SENT TO TOOBIT."
    );

    console.log(
        "No mock order is being used."
    );

    console.log(
        "The Exchange will decide whether the order is accepted or rejected."
    );


    // ==================================================
    // EXECUTE
    // ==================================================

    try {

        const result =
            await ExecutionEngine.execute(
                signal,
                riskPlan
            );


        printResult(
            "TEST 4 REAL EXECUTION RESULT",
            result
        );


        console.log(
            "\n🔎 REAL EXECUTION FINISHED"
        );


        // ==================================================
        // BLOCKED BEFORE EXCHANGE
        // ==================================================

        if (
            result?.blocked === true
        ) {

            console.log(
                "\n🟡 REAL ORDER DID NOT REACH EXCHANGE"
            );

            console.log(
                "Blocked at:",
                result.reason
            );

            console.log(
                "Message:",
                result.message
            );

            return;

        }


        // ==================================================
        // SUCCESS
        // ==================================================

        if (
            result?.success === true
        ) {

            console.log(
                "\n🚨 REAL ORDER ACCEPTED"
            );

            console.log(
                "The order appears to have been accepted by the execution path."
            );

            console.log(
                "Order ID:",
                result.orderId ?? "N/A"
            );

            console.dir(
                result,
                {
                    depth:
                        null
                }
            );

            return;

        }


        // ==================================================
        // REJECTED
        // ==================================================

        console.log(
            "\n🟠 REAL ORDER REJECTED"
        );

        console.log(
            "The request reached the execution path but was not successful."
        );


        // ----------------------------------------------
        // Print possible Exchange error fields
        // ----------------------------------------------

        console.log(
            "\n🔎 EXCHANGE ERROR DETAILS:"
        );

        console.log(
            "code:",
            result?.code ?? null
        );

        console.log(
            "error:",
            result?.error ?? null
        );

        console.log(
            "message:",
            result?.message ?? null
        );

        console.log(
            "msg:",
            result?.msg ?? null
        );

        console.log(
            "status:",
            result?.status ?? null
        );

        console.log(
            "orderId:",
            result?.orderId ?? null
        );

        console.log(
            "\n🔎 FULL RESULT:"
        );

        console.dir(
            result,
            {
                depth:
                    null
            }
        );


        // ==================================================
        // INSUFFICIENT BALANCE DETECTION
        // ==================================================

        const text =
            JSON.stringify(
                result
            )
                .toLowerCase();


        if (
            text.includes("insufficient") ||
            text.includes("balance") ||
            text.includes("margin") ||
            text.includes("fund")
        ) {

            console.log(
                "\n💰 INSUFFICIENT BALANCE / MARGIN ERROR DETECTED"
            );

            console.log(
                "The Exchange response indicates insufficient funds or margin."
            );

        }

    }
    catch(error) {

        console.log(
            "\n🔴 REAL EXECUTION THREW ERROR"
        );


        console.log(
            "Error name:",
            error?.name
        );

        console.log(
            "Error message:",
            error?.message
        );


        console.log(
            "\n🔎 FULL ERROR:"
        );

        console.dir(
            error,
            {
                depth:
                    null
            }
        );


        const text =
            JSON.stringify(
                error
            )
                .toLowerCase();


        if (
            text.includes("insufficient") ||
            text.includes("balance") ||
            text.includes("margin") ||
            text.includes("fund")
        ) {

            console.log(
                "\n💰 INSUFFICIENT BALANCE / MARGIN ERROR DETECTED"
            );

        }

    }

}


// ==========================================================
// RUN TESTS
// ==========================================================

async function runTests() {

    console.log(
        "\n=================================================="
    );

    console.log(
        "🚀 MTBP REAL EXECUTION ENGINE TEST SUITE"
    );

    console.log(
        "=================================================="
    );


    console.log(
        "\nExchange:",
        exchange
    );

    console.log(
        "Symbol:",
        symbol
    );


    console.log(
        "\n⚠ WARNING:"
    );

    console.log(
        "TEST 4 uses the REAL Toobit API."
    );

    console.log(
        "No mock order is used."
    );


    try {

        // ------------------------------------------
        // Gate tests
        // ------------------------------------------

        await test1BotStopped();

        await test2ExchangeStopped();

        await test3AllGatesOpen();


        // ------------------------------------------
        // Real execution
        // ------------------------------------------

        await test4RealExecution();


        console.log(
            "\n=================================================="
        );

        console.log(
            "🏁 ALL TESTS FINISHED"
        );

        console.log(
            "=================================================="
        );

    }
    catch(error) {

        console.error(
            "\n❌ TEST SUITE ERROR"
        );

        console.error(
            error
        );

    }

}


runTests();