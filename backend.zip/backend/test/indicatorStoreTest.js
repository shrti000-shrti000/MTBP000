import IndicatorStore from "../indicators/core/IndicatorStore.js";

async function test() {

    console.log("START INDICATOR STORE TEST");


    await IndicatorStore.ready;


    console.log(
        "DATABASE LOADED"
    );


    // SET TEST

    IndicatorStore.set(
        "TOOBIT",
        "BTCUSDT",
        "1m",
        "RSI",
        55.5
    );


    console.log(
        "SET DONE"
    );


    // GET TEST

    const value =
        IndicatorStore.get(
            "TOOBIT",
            "BTCUSDT",
            "1m",
            "RSI"
        );


    console.log(
        "GET VALUE:",
        value
    );


    console.log(
        "STORE SIZE:",
        IndicatorStore.size()
    );


}


test();