import { ToobitExchange } from "../exchange/toobitExchange00.js";


async function testListenKey() {

    console.log(
        "🚀 START LISTEN KEY TEST"
    );


    const toobit =
        new ToobitExchange();


    const result =
        await toobit.getListenKey();


    console.log(
        "📥 LISTEN KEY RESPONSE:"
    );


    console.log(
        JSON.stringify(
            result,
            null,
            2
        )
    );


}


testListenKey()

.catch(

    error => {

        console.error(
            "❌ ERROR:",
            error
        );

    }

);