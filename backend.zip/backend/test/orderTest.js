
// ======================================================
// MTBP
// Combined Paper Trading Test
//
// تست یکپارچه:
//
// 1. RESET PAPER ACCOUNT
// 2. OPEN PAPER ORDER
// 3. CHECK ACCOUNT AFTER OPEN
// 4. CHECK OPEN POSITION
// 5. CLOSE POSITION
// 6. CHECK ACCOUNT AFTER CLOSE
// 7. CHECK CLOSED POSITION
//
// فقط Paper Mode
// هیچ سفارش واقعی به صرافی ارسال نمی‌شود.
// ======================================================

import PaperTradingManager
    from "../config/PaperTradingManager.js";

import OrderStore
    from "../storage/OrderStore.js";

import PositionStore from "../risk/PositionStore.js";

import { ExchangeManager }
    from "../exchange/exchangeManager.js";

import OrderExecutor
    from "../execution/OrderExecutor.js";


// ======================================================
// TEST
// ======================================================

async function runCombinedPaperTest() {

    console.log("\n========================================");
    console.log("🚀 START COMBINED PAPER TEST");
    console.log("========================================\n");


    // ==================================================
    // 1. WAIT FOR PAPER ACCOUNT
    // ==================================================

    await PaperTradingManager.waitUntilReady();


    // ==================================================
    // 2. RESET ACCOUNT
    // ==================================================

    console.log("🧹 RESET PAPER ACCOUNT...");


    const reset =
        await PaperTradingManager.reset(1000);


    console.log(
        "RESET:",
        reset
    );


    console.log(
        "ACCOUNT AFTER RESET:",
        JSON.stringify(
            PaperTradingManager.getState(),
            null,
            2
        )
    );


    // ==================================================
    // 3. CREATE EXCHANGE MANAGER
    // ==================================================

    console.log("\n🔌 INITIALIZING EXCHANGE MANAGER...");


    const exchangeManager =
        new ExchangeManager();


    await exchangeManager.init();


    // ==================================================
    // 4. CONNECT ORDER EXECUTOR
    // ==================================================

    OrderExecutor.setExchangeManager(
        exchangeManager
    );


    // ==================================================
    // 5. CREATE PAPER OPEN ORDER
    //
    // Price = 60,000
    // Quantity = 0.01 BTC
    //
    // Notional = 600 USDT
    // Leverage = 1
    // Required Margin = 600 USDT
    //
    // Expected:
    //
    // Balance = 1000
    // Used Margin = 600
    // Available Balance = 400
    // ==================================================

   const openOrder = {
  exchange:
            "TOOBIT",

        symbol:
            "BTC-SWAP-USDT",

        side:
            "BUY_OPEN",

        type:
            "LIMIT",

        quantity:
            0.01,

        price:
            60000,
        priceType:
            "INPUT",

        leverage:
            1

    };


    console.log(
        "\n📤 OPEN PAPER ORDER:"
    );


    console.log(
        JSON.stringify(
            openOrder,
            null,
            2
        )
    );


    // ==================================================
    // 6. EXECUTE OPEN
    // ==================================================

    const openResult =
        await OrderExecutor.execute(
            openOrder
        );


    console.log(
        "\n📥 OPEN RESULT:"
    );


    console.log(
        JSON.stringify(
            openResult,
            null,
            2
        )
    );


    // ==================================================
    // 7. ACCOUNT AFTER OPEN
    // ==================================================

    console.log(
        "\n💰 ACCOUNT AFTER OPEN:"
    );


    console.log(
        JSON.stringify(
            PaperTradingManager.getState(),
            null,
            2
        )
    );


    // ==================================================
    // 8. OPEN POSITIONS
    // ==================================================

    console.log(
        "\n📊 OPEN POSITIONS:"
    );


    const openPositions =
        PositionStore.getOpenPositions();


    console.log(
        JSON.stringify(
            openPositions,
            null,
            2
        )
    );


    // ==================================================
    // 9. FIND CREATED POSITION
    // ==================================================

    const position =
        openResult?.position ??
        openPositions?.find(
            p =>
                p.symbol ===
                openOrder.symbol
        );


    if (!position) {

        throw new Error(
            "❌ OPEN POSITION WAS NOT CREATED"
        );

    }


    console.log(
        "\n🟢 POSITION CREATED:"
    );


    console.log(
        JSON.stringify(
            position,
            null,
            2
        )
    );


    // ==================================================
    // 10. CLOSE POSITION
    //
    // Same entry/exit price:
    //
    // Entry = 60,000
    // Exit  = 60,000
    //
    // Expected PnL = 0
    // ==================================================

    console.log(
        "\n📕 CLOSING POSITION..."
    );


    const closeResult =
        await PositionStore.close(

            position.id,

            60000,

            "COMBINED PAPER TEST"

        );


    console.log(
        "\n📥 CLOSE RESULT:"
    );


    console.log(
        JSON.stringify(
            closeResult,
            null,
            2
        )
    );


    // ==================================================
    // 11. ACCOUNT AFTER CLOSE
    // ==================================================

    console.log(
        "\n💰 ACCOUNT AFTER CLOSE:"
    );


    console.log(
        JSON.stringify(
            PaperTradingManager.getState(),
            null,
            2
        )
    );


    // ==================================================
    // 12. OPEN POSITIONS AFTER CLOSE
    // ==================================================

    console.log(
        "\n📊 OPEN POSITIONS AFTER CLOSE:"
    );


    console.log(
        JSON.stringify(
            PositionStore.getOpenPositions(),
            null,
            2
        )
    );


    // ==================================================
    // 13. ORDER STORE
    // ==================================================

    console.log(
        "\n📦 ORDER STORE:"
    );


    console.log(
        JSON.stringify(
            OrderStore.getAll(),
            null,
            2
        )
    );


    // ==================================================
    // 14. FINAL ACCOUNT
    // ==================================================

    console.log(
        "\n========================================"
    );

    console.log(
        "🏁 FINAL PAPER ACCOUNT"
    );

    console.log(
        "========================================"
    );


    console.log(
        JSON.stringify(
            PaperTradingManager.getState(),
            null,
            2
        )
    );


    console.log(
        "\n========================================"
    );

    console.log(
        "✅ COMBINED PAPER TEST FINISHED"
    );

    console.log(
        "========================================\n"
    );

}



// ======================================================
// RUN
// ======================================================

runCombinedPaperTest()

    .catch(
        error => {

            console.error(
                "\n❌ COMBINED PAPER TEST ERROR:",
                error
            );

            process.exit(1);

        }
    );

