import PaperTradingManager
    from "../config/PaperTradingManager.js";

import PaperAccountStore
    from "../storage/PaperAccountStore.js";

import PositionStore
    from "../risk/PositionStore.js";

import OrderExecutor
    from "../execution/OrderExecutor.js";


// ======================================================
// PAPER FULL INTEGRATION TEST
// ======================================================

async function main() {

    console.log("");
    console.log("==============================================");
    console.log("🚀 PAPER FULL INTEGRATION TEST");
    console.log("==============================================");


    // ==================================================
    // WAIT FOR STORES
    // ==================================================

    await PaperTradingManager.waitUntilReady();

    await PaperAccountStore.ready;

    await PositionStore.ready;


    // ==================================================
    // RESET ACCOUNT
    // ==================================================

    console.log("");
    console.log("🧹 RESET PAPER ACCOUNT");

    const reset =
        await PaperTradingManager.reset(1000);

    console.log("RESET:", reset);


    // ==================================================
    // INITIAL STATE
    // ==================================================

    console.log("");
    console.log("========== INITIAL ACCOUNT ==========");

    console.log(
        JSON.stringify(
            PaperTradingManager.getState(),
            null,
            2
        )
    );


    // ==================================================
    // OPEN PAPER ORDER
    // ==================================================

    console.log("");
    console.log("========== OPEN PAPER ORDER ==========");


    const order = {

        exchange:
            "TOOBIT",

        symbol:
          "BTC-SWAP-USDT",

        side:
            "BUY_OPEN",

        action:
            "OPEN",

        type:
            "MARKET",

        quantity:
            0.01,

        price:
            60000,

        leverage:
            1

    };


    const result =
        await OrderExecutor.execute(
            order
        );


    console.log(
        "ORDER RESULT:"
    );

    console.log(
        JSON.stringify(
            result,
            null,
            2
        )
    );


    // ==================================================
    // ACCOUNT AFTER OPEN
    // ==================================================

    console.log("");
    console.log("========== ACCOUNT AFTER OPEN ==========");

    const accountAfterOpen =
        PaperAccountStore.getByExchange(
            "TOOBIT"
        );

    console.log(
        JSON.stringify(
            accountAfterOpen,
            null,
            2
        )
    );


    // ==================================================
    // OPEN POSITIONS
    // ==================================================

    console.log("");
    console.log("========== OPEN POSITIONS ==========");

    console.log(
        JSON.stringify(
            PositionStore.getOpenPositions(),
            null,
            2
        )
    );


    // ==================================================
    // SIMULATE PRICE INCREASE
    // ==================================================

    console.log("");
    console.log("========== PRICE UPDATE ==========");

    const newPrice =
        61000;


    PositionStore.updatePrice(

        "BTC-SWAP-USDT",

        newPrice

    );


    const openPositions =
        PositionStore.getOpenPositions();


    console.log(
        JSON.stringify(
            openPositions,
            null,
            2
        )
    );


    // ==================================================
    // SHOW PNL
    // ==================================================

    if (openPositions.length > 0) {

        const position =
            openPositions[0];


        console.log("");
        console.log("========== UNREALIZED PNL ==========");

        console.log(
            "Entry:",
            position.entryPrice
        );

        console.log(
            "Current:",
            position.currentPrice
        );

        console.log(
            "PnL:",
            position.pnl
        );

    }


    // ==================================================
    // ACCOUNT DURING OPEN POSITION
    // ==================================================

    console.log("");
    console.log("========== ACCOUNT DURING POSITION ==========");

    console.log(
        JSON.stringify(
            PaperAccountStore.getByExchange(
                "TOOBIT"
            ),
            null,
            2
        )
    );


    // ==================================================
    // CLOSE POSITION
    // ==================================================

    if (openPositions.length > 0) {

        const position =
            openPositions[0];


        console.log("");
        console.log("========== CLOSE POSITION ==========");


        const closed =
            await PositionStore.close(

                position.id,

                newPrice,

                "TEST_CLOSE",

                0

            );


        console.log(
            JSON.stringify(
                closed,
                null,
                2
            )
        );


        // ==================================================
        // APPLY REALIZED PNL
        // ==================================================

        const realizedPnL =
            Number(
                closed?.pnl?.value ?? 0
            );


        console.log("");
        console.log(
            "========== APPLY REALIZED PNL =========="
        );


        console.log(
            "REALIZED PNL:",
            realizedPnL
        );


        await PaperTradingManager.applyRealizedPnL(
            realizedPnL
        );

    }


    // ==================================================
    // FINAL ACCOUNT
    // ==================================================

    console.log("");
    console.log("==============================================");
    console.log("========== FINAL PAPER ACCOUNT ===============");
    console.log("==============================================");


    console.log(
        JSON.stringify(
            PaperTradingManager.getState(),
            null,
            2
        )
    );


    // ==================================================
    // FINAL POSITIONS
    // ==================================================

    console.log("");
    console.log("========== FINAL OPEN POSITIONS ==========");

    console.log(
        JSON.stringify(
            PositionStore.getOpenPositions(),
            null,
            2
        )
    );


    console.log("");
    console.log("========== FINAL CLOSED POSITIONS ==========");

    console.log(
        JSON.stringify(
            PositionStore.getClosedPositions(),
            null,
            2
        )
    );


    console.log("");
    console.log("==============================================");
    console.log("✅ PAPER FULL INTEGRATION TEST FINISHED");
    console.log("==============================================");


    process.exit(0);

}


main()

    .catch(error => {

        console.error(
            "❌ TEST ERROR:",
            error
        );

        process.exit(1);

    });