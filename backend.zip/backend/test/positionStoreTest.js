// ======================================================
// MTBP POSITION STORE TEST
// PostgreSQL Persistence Test
// ======================================================

import positionStore from "../risk/positionStore.js";


await positionStore.ready;



async function test() {

    console.log(
        "START POSITION STORE TEST"
    );


    // صبر برای لود دیتابیس
    if (positionStore.ready) {

        await positionStore.ready;

    }


    console.log(
        "DATABASE LOADED"
    );


    console.log(
        "CURRENT POSITIONS:",
        positionStore.getAll().length
    );



    // ================================
    // ADD TEST POSITION
    // ================================

    const position =
        positionStore.add({

            exchange:
                "TOOBIT",

            symbol:
                "BTCUSDT",

            side:
                "LONG",

            entryPrice:
                60000,

            quantity:
                0.01,

            leverage:
                1,

            stopLoss:
                59000,

            takeProfit:
                62000,

            timeframe:
                "1m",

            confidence:
                80,

            signalId:
                "TEST_SIGNAL"

        });



    console.log(
        "POSITION CREATED:",
        position
    );



    // ================================
    // UPDATE PRICE
    // ================================

    positionStore.updatePrice(
        "BTCUSDT",
        61000
    );


    console.log(
        "OPEN POSITIONS:",
        positionStore.getOpenPositions()
    );



    // ================================
    // CLOSE TEST
    // ================================

    const closed =
        positionStore.close(
            position.id,
            61500,
            "TEST CLOSE"
        );


    console.log(
        "CLOSED POSITION:",
        closed
    );



    console.log(
        "FINAL COUNT:",
        positionStore.getAll().length
    );


    process.exit(0);

}



test();