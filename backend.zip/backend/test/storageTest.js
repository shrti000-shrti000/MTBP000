import StorageManager from "../storage/StorageManager.js";


async function test() {


    await StorageManager.save(
        "test",
        {
            hello: "MTBP",
            time: Date.now()
        }
    );


    const data =
        await StorageManager.load(
            "test"
        );


    console.log(
        "LOADED DATA:",
        data
    );


}


test();