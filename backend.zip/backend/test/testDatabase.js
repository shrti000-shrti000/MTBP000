import Database from "../storage/database/Database.js";


console.log(
    "🧪 DATABASE TEST START"
);


await Database.test();