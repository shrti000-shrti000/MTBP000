// backend/test/testExecution.js


import { ExchangeManager } from "../exchange/exchangeManager.js";

import OrderExecutor from "../execution/OrderExecutor.js";

import ExecutionEngine from "../execution/ExecutionEngine.js";



async function test() {


    console.log(
        "🚀 START EXECUTION TEST"
    );



    // ======================================
    // INIT EXCHANGE
    // ======================================

    const exchangeManager =

        new ExchangeManager();



    await exchangeManager.init();



    console.log(
        "🟢 EXCHANGE READY"
    );



    // ======================================
    // CONNECT ORDER EXECUTOR
    // ======================================

    OrderExecutor.setExchangeManager(

        exchangeManager

    );



    ExecutionEngine.setOrderExecutor(

        OrderExecutor

    );



    console.log(
        "🟢 EXECUTION ENGINE CONNECTED"
    );



    // ======================================
    // TEST SIGNAL
    // ======================================

    const signal = {


        exchange:
            "TOOBIT",


        symbol:
            "BTCUSDT",


        side:
            "LONG",


        action:
            "OPEN",


        confidence:
            80,


        timeframe:
            "1m"

    };





    const riskPlan = {


        exchange:
            "TOOBIT",


        symbol:
            "BTCUSDT",


        orderType:
            "MARKET",


        quantity:
            1,


        leverage:
            1,


        stopLoss:
            63000,


        takeProfit:
            66000


    };




    const result =

        await ExecutionEngine.execute(

            signal,

            riskPlan

        );




    console.log(
        "=============================="
    );


    console.log(
        "EXECUTION RESULT:"
    );


    console.log(
        result
    );


    console.log(
        "=============================="
    );


}



test();