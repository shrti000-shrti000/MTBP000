import PositionExecutor from "../risk/PositionExecutor.js";

import PositionStore from "../risk/PositionStore.js";



console.log(
    "===== POSITION TEST START ====="
);



const tradePlan = {


    allowed: true,


    side: "LONG",


    entryPrice: 100,


    quantity: 5,


    leverage: 1,


    stopLoss: 95,


    takeProfit: 110,


};



const position =

    PositionExecutor.open({

        exchange: "TOOBIT",

        symbol: "BTCUSDT",

        tradePlan,

    });



console.log(

    "OPEN POSITION:",

    position

);



console.log(

    "ALL POSITIONS:",

    PositionStore.getAll()

);



console.log(

    "===== POSITION TEST END ====="

);