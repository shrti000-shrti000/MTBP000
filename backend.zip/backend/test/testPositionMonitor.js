import PositionExecutor from "../risk/PositionExecutor.js";

import PositionStore from "../risk/PositionStore.js";

import PositionMonitor from "../risk/PositionMonitor.js";

import ClosedPositionStore from "../risk/ClosedPositionStore.js";



console.log(
    "===== MONITOR TEST START ====="
);



PositionExecutor.open({

    exchange: "TOOBIT",

    symbol: "BTCUSDT",

    tradePlan: {

        allowed: true,

        side: "LONG",

        entryPrice: 100,

        quantity: 1,

        stopLoss: 95,

        takeProfit: 110,

    }

});



console.log(
    "BEFORE:",
    PositionStore.getAll()
);



// قیمت به TP میرسد

PositionStore.updatePrice(

    "BTCUSDT",

    110

);



PositionMonitor.update();



console.log(
    "OPEN:",
    PositionStore.getAll()
);



console.log(
    "CLOSED:",
    ClosedPositionStore.getAll()
);



console.log(
    "===== MONITOR TEST END ====="
);