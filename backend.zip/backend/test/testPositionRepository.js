import PositionRepository from "../storage/repositories/PositionRepository.js";


console.log("🚀 TEST POSITION REPOSITORY");


try {

    const positions =
        await PositionRepository.loadOpenPositions();


    console.log(
        "OPEN POSITIONS FROM DATABASE:",
        positions.length
    );


    console.log(
        JSON.stringify(
            positions,
            null,
            2
        )
    );


    process.exit(0);


}
catch(error) {

    console.error(
        "❌ TEST FAILED:",
        error.message
    );

    process.exit(1);

}