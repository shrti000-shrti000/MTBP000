import PostgresAdapter from "../storage/database/PostgresAdapter.js";
import crypto from "crypto";


console.log("🧪 POSTGRES INSERT TEST START");


try {

    const position = {

        id: crypto.randomUUID(),

        position_code: "TEST-POS-001",

        exchange: "toobit",

        symbol: "BTCUSDT",

        side: "LONG",

        status: "OPEN",

        entry_price: 60000,

        quantity: 0.01,

        leverage: 1,

        timeframe: "1m",

        confidence: 80

    };


    const saved =
        await PostgresAdapter.insert(
            "positions",
            position
        );


    console.log(
        "INSERT RESULT:",
        saved
    );


    const rows =
        await PostgresAdapter.findAll(
            "positions"
        );


    console.log(
        "ALL POSITIONS:",
        rows
    );


    console.log(
        "✅ POSTGRES INSERT SUCCESS"
    );


}
catch(error) {

    console.error(
        "❌ INSERT FAILED:",
        error.message
    );

}