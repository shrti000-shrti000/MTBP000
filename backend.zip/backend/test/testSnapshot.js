import SnapshotManager from "../storage/snapshots/SnapshotManager.js";


console.log("🧪 SNAPSHOT TEST START");


const testData = {

    symbol: "BTCUSDT",

    timeframe: "1m",

    candles: [
        {
            open: 100,
            close: 105,
            time: Date.now()
        }
    ],

    indicator: {

        RSI: 55,

        EMA: 102

    }

};



const saved =
SnapshotManager.save(
    "test_market",
    testData
);



console.log(
    "SAVE:",
    saved
);



const restored =
SnapshotManager.load(
    "test_market"
);



console.log(
    "RESTORED:",
    restored
);



if (
    restored &&
    restored.symbol === "BTCUSDT"
) {

    console.log(
        "✅ SNAPSHOT RESTORE SUCCESS"
    );

}
else {

    console.log(
        "❌ SNAPSHOT RESTORE FAILED"
    );

}