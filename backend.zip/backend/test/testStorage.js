

import StorageManager from "../storage/StorageManager.js";


await StorageManager.init();


await StorageManager.save(
    "test",
    {
        status:"OK"
    }
);


const result =
await StorageManager.load("test");


console.log(result);