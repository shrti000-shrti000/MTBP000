import storageConfig from "../storage/config/storageConfig.js";


console.log(
    "🧪 STORAGE CONFIG TEST"
);


console.log(
    storageConfig
);


if (
    storageConfig.driver === "postgres"
) {

    console.log(
        "✅ POSTGRES MODE ACTIVE"
    );

}
else {

    console.log(
        "🟡 MEMORY MODE ACTIVE"
    );

}