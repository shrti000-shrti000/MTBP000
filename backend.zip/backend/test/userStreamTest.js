import { ToobitExchange } from "../exchange/toobitExchange00.js";
import ToobitUserStream from "../exchange/toobit/ToobitUserStream.js";

import OrderEventHandler from "../execution/OrderEventHandler.js";

import PositionSync from "../risk/PositionSync.js";
async function testUserStream() {


    console.log(
        "🚀 START USER STREAM TEST"
    );


    const toobit =
        new ToobitExchange();



    const response =
        await toobit.getListenKey();



    const listenKey =
        response.listenKey;



    console.log(
        "🔑 LISTEN KEY:",
        listenKey
    );



    ToobitUserStream.onMessage(

    (data)=>{


        console.log(

            "📩 USER EVENT:",

            data

        );


        OrderEventHandler.handle(

            data

        );
        
        PositionSync.handle(

    data

);

    }

);



    ToobitUserStream.connect(

        listenKey

    );


}


testUserStream()

.catch(

    error=>{

        console.error(

            "❌ ERROR:",

            error

        );

    }

);