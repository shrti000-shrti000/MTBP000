
import CalibrationEngine from "./calibration/CalibrationEngine.js";
import strategySettings from "./config/strategySettings.js";

const OPTIONS = {
    exchange: "TOOBIT",
    symbol: "BTCUSDT",
    timeframe: "15m",
    candleLimit: 470
};

// Current calibration candidates
const RSI_BUY_LEVEL = 35;
const RSI_SELL_LEVEL = 65;

const MACD_FAST = 15;
const MACD_SLOW = 30;
const MACD_SIGNAL = 5;

// EMA parameters to test
const EMA_TESTS = [
    { fast: 5,  slow: 20 },
    { fast: 5,  slow: 30 },
    { fast: 5,  slow: 50 },

    { fast: 9,  slow: 20 },
    { fast: 9,  slow: 30 },
    { fast: 9,  slow: 50 },

    { fast: 11, slow: 30 },
    { fast: 11, slow: 50 },
    { fast: 11, slow: 75 },

    { fast: 15, slow: 30 },
    { fast: 15, slow: 50 },
    { fast: 15, slow: 75 },

    { fast: 20, slow: 50 },
    { fast: 20, slow: 75 },
    { fast: 20, slow: 100 }
];

function round(value, digits = 4) {
    return Number.isFinite(value)
        ? Number(value.toFixed(digits))
        : 0;
}

async function runTest(ema) {

    const settingsOverride = {
        ...strategySettings,

        rsi: {
            ...strategySettings.rsi,
            buyLevel: RSI_BUY_LEVEL,
            sellLevel: RSI_SELL_LEVEL
        },

        ema: {
            ...strategySettings.ema,
            fast: ema.fast,
            slow: ema.slow
        },

        macd: {
            ...strategySettings.macd,
            fast: MACD_FAST,
            slow: MACD_SLOW,
            signal: MACD_SIGNAL
        },

        volume: {
            ...strategySettings.volume
        }
    };

    const result = await CalibrationEngine.run({
        ...OPTIONS,
        strategySettingsOverride: settingsOverride
    });

    const metrics = result.metrics || {};

    return {
        EMA: `${ema.fast}/${ema.slow}`,

        Fast: ema.fast,
        Slow: ema.slow,

        NetProfit: round(metrics.netProfit, 4),
        PF: round(metrics.profitFactor, 4),
        WinRate: round(metrics.winRate, 2),
        Trades: metrics.tradeCount,
        Expectancy: round(metrics.expectancy, 4),
        MaxDD: round(metrics.maxDrawdown, 4),

        Long: metrics.longTrades,
        LongWin: round(metrics.longWinRate, 2),

        Short: metrics.shortTrades,
        ShortWin: round(metrics.shortWinRate, 2),

        Fees: round(metrics.totalFees, 4)
    };
}

async function main() {

    console.log("\n========================================");
    console.log("        EMA PARAMETER CALIBRATION");
    console.log("========================================\n");

    console.log(
        `RSI candidate: ${RSI_BUY_LEVEL}/${RSI_SELL_LEVEL}`
    );

    console.log(
        `MACD candidate: ${MACD_FAST}/${MACD_SLOW}/${MACD_SIGNAL}`
    );

    console.log("\nTesting EMA combinations...\n");

    const results = [];

    for (const ema of EMA_TESTS) {

        console.log(
            `Testing EMA ${ema.fast}/${ema.slow} ...`
        );

        const result = await runTest(ema);

        results.push(result);
    }

    console.log("\n========================================");
    console.log("             EMA RESULTS");
    console.log("========================================\n");

    console.table(results);

    console.log("\n========================================");
    console.log("         CURRENT EMA BASELINE");
    console.log("========================================\n");

    const baseline = results.find(
        x =>
            x.Fast === strategySettings.ema.fast &&
            x.Slow === strategySettings.ema.slow
    );

    if (baseline) {
        console.table([baseline]);
    }

    console.log("\n========================================");
    console.log("        EMA CALIBRATION COMPLETE");
    console.log("========================================\n");
}

main().catch(error => {
    console.error("\n❌ EMA CALIBRATION ERROR\n");
    console.error(error);
    process.exit(1);
});
