const res = await fetch("https://api.toobit.com/api/v1/exchangeInfo");

const json = await res.json();

console.log("TOTAL:", json.symbols.length);

console.log(
    json.symbols
        .filter(x => x.status === "TRADING")
        .slice(0,20)
        .map(x => x.symbol)
);