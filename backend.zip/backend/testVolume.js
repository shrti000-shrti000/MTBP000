import Volume from "./indicators/modules/Volume.js";

const volumeIndicator = new Volume({
    period: 20
});

// 20 کندل قبلی با حجم 100
for (let i = 1; i <= 20; i++) {

    volumeIndicator.update({
        time: i,
        volume: 100
    });

}

// کندل شماره 21 با حجم 200
volumeIndicator.update({
    time: 21,
    volume: 200
});

console.log("\n========== VOLUME TEST ==========\n");

console.log(
    JSON.stringify(
        volumeIndicator.getVolume(),
        null,
        2
    )
);

console.log("\n=================================\n");